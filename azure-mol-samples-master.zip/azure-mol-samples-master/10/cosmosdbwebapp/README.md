Edit config.js and enter your own values for:

    config.endpoint
    config.primaryKey

The values for both of these are provided in the output from ../create_cosmosdb.py script
You can also obtain these values in the Azure portal under 'Keys' for your Cosmos DB database

Once updated, either run locally with `npm start` or push to Azure Web Apps
