**NOTE** - If you run into issues with some of these sample scripts and applications, please check the 2nd edition versions at https://github.com/fouldsy/azure-mol-samples-2nd-ed. The 2nd edition samples are updated for the latest SDKs and Azure behavior. These 1st edition samples are left as-is so they don't deviate from what's actually publish in the 1st edition of the book.

Supporting resources for "Learn Azure in a Month of Lunches" by Manning Publications
More info on the book available here - https://www.manning.com/books/learn-azure-in-a-month-of-lunches

This repo contains sample scripts used throughout the chapters. Azure CLI, Azure PowerShell, and Azure Resource Manager templates ares shown that detail the concepts discussed in each chapter.

This repo isn't really designed to be used as a standalone resource. You're missing a lot of the context with the book!

Please submit a PR if you find any issues.
